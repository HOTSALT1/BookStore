package kr.co.bootpay.javaApache.model.request;

/**
 * Created by ehowlsla on 2017. 8. 3..
 */
public class Cancel {
    public String receipt_id;
    public String name;
    public String reason;
    public Double price;
}
