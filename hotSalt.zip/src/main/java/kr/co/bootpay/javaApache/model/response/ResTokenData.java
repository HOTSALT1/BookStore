package kr.co.bootpay.javaApache.model.response;

/**
 * Created by ehowlsla on 2018. 5. 29..
 */
public class ResTokenData {
    public String token;
    public long server_time;
    public long expired_at;
}
