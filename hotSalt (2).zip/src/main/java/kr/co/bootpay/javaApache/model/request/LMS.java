package kr.co.bootpay.javaApache.model.request;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ehowlsla on 2019. 8. 23..
 */
public class LMS {
    public String sp;
    public List<String> rps = new ArrayList();
    public String msg;
    public String sj;
}
