package kr.co.bootpay.javaApache.model.response;

/**
 * Created by ehowlsla on 2018. 5. 29..
 */
public class ResDefault {
    public int status;
    public int code;
    public String message;
}
