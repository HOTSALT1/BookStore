package kr.co.bootpay.javaApache.model.request;

/**
 * Created by ehowlsla on 2018. 5. 29..
 */
public class Token {
    public String application_id;
    public String private_key;

}

