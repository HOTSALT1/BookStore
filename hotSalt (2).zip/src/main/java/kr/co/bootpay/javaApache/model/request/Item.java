package kr.co.bootpay.javaApache.model.request;

/**
 * Created by ehowlsla on 2019. 8. 23..
 */
public class Item {
    public String item_name;
    public int qty;
    public String unique;
    public long price;
    public String cat1;
    public String cat2;
    public String cat3;
}
