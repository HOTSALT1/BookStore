package order.bean;

public class OrderDTO {

}
